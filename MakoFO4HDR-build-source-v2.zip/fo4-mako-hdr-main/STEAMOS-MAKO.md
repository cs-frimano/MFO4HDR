# Fallout 4 HDR on SteamOS with MAKO

MakoFO4HDR is a Windows x64 F4SE plugin. SteamOS runs it inside Fallout 4's
Proton prefix; MAKO Decky supplies the Vulkan/Gamescope HDR presentation path.
The Decky plugin and MakoFO4HDR do different jobs, so both need to be enabled.

## Requirements

- Steam Deck OLED or an HDR capable external display, with HDR enabled in
  Gaming Mode. The built-in LCD panel does not support HDR.
- Fallout 4 launched with Proton/Proton GE and a matching F4SE build.
- MakoFO4HDR built for the exact Fallout 4 runtime version in use. Its current
  source profiles list runtimes `1.10.163`, `1.10.984`, and `1.11.240`.
- MAKO Decky installed, with MAKO Renderer installed from the Decky page.

## Setup

1. Install F4SE for the Fallout 4 runtime. After a Windows x64 build, copy the
   project package to SteamOS and run the installer from its root:

   ```bash
   bash scripts/install-steamos.sh --game-root "/path/to/Fallout 4"
   ```

   For Mod Organizer 2, use the MO2 mod directory instead:

   ```bash
   bash scripts/install-steamos.sh --mo2-mod "/path/to/MO2/mods/MakoFO4HDR"
   ```

   The installer places the files in `Data/F4SE/Plugins/` and keeps an existing
   `MakoFO4HDR.ini` so upgrades preserve your settings. Direct game installs
   use this path:

   ```text
   Fallout 4/Data/F4SE/Plugins/
   ```

   Verify that `MakoFO4HDR.dll` and `MakoFO4HDR.ini` are there. Do not put the
   DLL in the game's top-level folder. The source checkout does not include a
   compiled DLL; the installer reports this until a Windows x64 build is copied
   into `dist/universal/Data/F4SE/Plugins/`.

2. In MAKO Decky, open Fallout 4's profile. Turn on **Enable HDR (Restart)**,
   leave **Gamescope WSI** off, save, and restart the game.

3. In Steam > Fallout 4 > Properties > General, use MAKO's wrapper as the
   launch option (use the path MAKO displays if it differs):

   ```text
   /home/deck/.local/bin/mako-run %command%
   ```

   Keep any existing launch arguments by placing them after `%command%`.
   MAKO's wrapper sets both HDR environment values for the Proton game when
   its HDR option is enabled; do not add a second wrapper or replace the
   command with a direct `Fallout4.exe` launch.

4. Launch Fallout 4 through Steam/F4SE. Press **Alt+H** to open MakoFO4HDR's
   settings panel. Enable HDR in MakoFO4HDR and tune its display peak to your
   screen. The plugin's HDR status should report active after MAKO and the
   display HDR path are active.

MakoFO4HDR does not add an entry to Fallout 4's **Mods** menu or to Mod
Configuration Menu (MCM). Its controls are the **Alt+H** overlay and
`MakoFO4HDR.ini` in `Data/F4SE/Plugins`.

## If HDR stays off

- Confirm the game is using the same Fallout 4 runtime targeted by the
  installed MakoFO4HDR build, and that F4SE itself loads under the selected
  Proton version. F4SE plugins are Windows DLLs; a Linux-native build will not
  load in the Windows game process.
- Confirm MAKO Renderer is installed, the Fallout 4 profile matched the game,
  **Enable HDR (Restart)** is on, and **Gamescope WSI** is off.
- Confirm the display is in HDR mode before starting the game. Restart after
  changing the MAKO HDR toggle or changing displays.
- Check `Documents/My Games/Fallout4/F4SE/f4se.log`,
  `Documents/My Games/Fallout4/F4SE/MakoFO4HDR.log`, and MAKO diagnostics from
  the same launch. The MakoFO4HDR startup entry reports
  `mako_hdr_toggle_on=true` only when both MAKO variables are present; later
  renderer diagnostics report the exact swap-chain or color-space rejection.

With the profile toggle enabled, MAKO's wrapper exports
`MAKO_DISABLE_HDR_EXPOSURE=0` and `DXVK_HDR=1`. MakoFO4HDR requires both, then
allows MAKO/DXVK's HDR path even when Proton's Windows display metadata does
not identify the physical HDR display. DXVK's swap chain must still advertise
PQ/BT.2020 presentation support and accept both HDR and SDR color-space
changes. The plugin's HDR output uses D3D11/DXGI, Proton's DXVK translation,
and MAKO's Gamescope bridge.

## Black or broken bloom workaround

The SteamOS config starts with **Bloom Strength** at **0%**, since 50% caused a
black bloom artifact in the reported Proton setup. This disables bloom while
leaving HDR and tone mapping enabled. After confirming stability, raise the
value gradually in **Alt+H → Image**. If corruption returns, set it back to
zero; this setting is independent from MAKO's HDR toggle.
