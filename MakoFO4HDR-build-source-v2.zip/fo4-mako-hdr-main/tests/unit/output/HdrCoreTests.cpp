// SPDX-License-Identifier: LicenseRef-FO4Isotope-GPL-3.0-or-later-with-CommonLibF4-Exceptions

#include "../UnitTestSuite.hpp"

#include "FO4Isotope/config/PluginConfiguration.hpp"
#include "FO4Isotope/output/Hdr10Color.hpp"
#include "FO4Isotope/output/HdrActivationPolicy.hpp"
#include "resources/HdrResourcePolicy.hpp"
#include "resources/ScenePromotionPolicy.hpp"
#include "FO4Isotope/output/RenderPipelineContract.hpp"
#include "reference/OperatorLutTestSupport.hpp"
#include "TestHarness.hpp"

#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <limits>
#include <string_view>
#include <utility>

namespace fo4hdr::tests {
namespace {

using test::EvaluateOperatorLutQuality;
using test::kOperatorLutPercentileDeltaEItp;
using test::OperatorLutMaximumDeltaEItp;
using test::OperatorLutQuality;
using test::OperatorLutQualityMeasurements;
using test::OperatorLutQualityRegion;

void TestBt709ToBt2020()
{
    const auto neutral = ConvertBt709ToBt2020({4.0, 4.0, 4.0});
    FO4HDR_CHECK(test::Approx(neutral.red, 4.0, 1.0e-7));
    FO4HDR_CHECK(test::Approx(neutral.green, 4.0, 1.0e-7));
    FO4HDR_CHECK(test::Approx(neutral.blue, 4.0, 1.0e-7));

    const auto red = ConvertBt709ToBt2020({1.0, 0.0, 0.0});
    FO4HDR_CHECK(test::Approx(red.red, 0.6274039149284363));
    FO4HDR_CHECK(test::Approx(red.green, 0.06909728795289993));
    FO4HDR_CHECK(test::Approx(red.blue, 0.0163914393633604));

    const auto green = ConvertBt709ToBt2020({0.0, 1.0, 0.0});
    FO4HDR_CHECK(test::Approx(green.red, 0.3292830288410187));
    FO4HDR_CHECK(test::Approx(green.green, 0.9195404052734375));
    FO4HDR_CHECK(test::Approx(green.blue, 0.08801330626010895));

    const auto blue = ConvertBt709ToBt2020({0.0, 0.0, 1.0});
    FO4HDR_CHECK(test::Approx(blue.red, 0.04331306740641594));
    FO4HDR_CHECK(test::Approx(blue.green, 0.01136231515556574));
    FO4HDR_CHECK(test::Approx(blue.blue, 0.8955952525138855));

    const auto emissive = ConvertBt709ToBt2020({8.0, 4.0, 0.0});
    FO4HDR_CHECK(emissive.red > 1.0);
    FO4HDR_CHECK(emissive.green > 1.0);
    FO4HDR_CHECK(emissive.blue > 0.0);

    for (const auto sample : {
             LinearRgb{1.0, 0.0, 0.0}, LinearRgb{0.0, 1.0, 0.0},
             LinearRgb{0.0, 0.0, 1.0}, LinearRgb{8.0, 4.0, 0.5},
             LinearRgb{203.0, 203.0, 203.0}})
    {
        const auto roundTrip = ConvertBt2020ToBt709ForComparison(
            ConvertBt709ToBt2020(sample));
        FO4HDR_CHECK(test::Approx(roundTrip.red, sample.red, 1.0e-12));
        FO4HDR_CHECK(test::Approx(roundTrip.green, sample.green, 1.0e-12));
        FO4HDR_CHECK(test::Approx(roundTrip.blue, sample.blue, 1.0e-12));
    }
}

void TestDisplayStandardsOracle()
{
    // Independent XYZ route from ITU primary coordinates and D65, without
    // rounding the combined RGB transform to the shader's binary32 precision.
    // https://www.itu.int/rec/R-REC-BT.709-6-201506-I/en
    // https://www.itu.int/rec/R-REC-BT.2020-2-201510-I/en
    using Matrix = std::array<std::array<double, 3>, 3>;
    constexpr Matrix narrowToXyz{{
        {0.4123907992659595, 0.3575843393838780, 0.1804807884018343},
        {0.2126390058715104, 0.7151686787677560, 0.0721923153607337},
        {0.0193308187155919, 0.1191947797946260, 0.9505321522496607}
    }};
    constexpr Matrix wideToXyz{{
        {0.6369580483012914, 0.1446169035862083, 0.1688809751641721},
        {0.2627002120112671, 0.6779980715188710, 0.0593017164698620},
        {0.0, 0.0280726930490874, 1.0609850577107910}
    }};
    for (const auto input : {
        LinearRgb{1, 0, 0}, LinearRgb{0, 1, 0}, LinearRgb{0, 0, 1},
        LinearRgb{203, 203, 203}, LinearRgb{-3, 8, -0.25},
        LinearRgb{65504, 0.0001, 32752}})
    {
        const auto output = ConvertBt709ToBt2020(input);
        for (std::size_t row = 0; row < 3; ++row) {
            const auto& a = narrowToXyz[row];
            const auto& b = wideToXyz[row];
            const double expected = a[0] * input.red + a[1] * input.green + a[2] * input.blue;
            const double actual = b[0] * output.red + b[1] * output.green + b[2] * output.blue;
            const double scale = std::max({1.0, std::abs(input.red),
                std::abs(input.green), std::abs(input.blue)});
            FO4HDR_CHECK(std::abs(actual - expected) <= scale * 5.0e-8);
        }
    }

}

void TestDisplaySignalContainment()
{
    const double infinity = std::numeric_limits<double>::infinity();
    const double nan = std::numeric_limits<double>::quiet_NaN();
    const auto bounded = ContainBt2020Nits({nan, -infinity, infinity}, 400.0);
    FO4HDR_CHECK(bounded.red == 0.0 && bounded.green == 0.0 && bounded.blue == 400.0);
    for (const double invalidPeak : {-1.0, 0.0, 10001.0, infinity, nan}) {
        const auto black = ContainBt2020Nits({100, 200, 300}, invalidPeak);
        FO4HDR_CHECK(black.red == 0.0 && black.green == 0.0 && black.blue == 0.0);
    }
    const auto preserved = ContainBt2020Nits({0.001, 203, 401}, 400);
    FO4HDR_CHECK(preserved.red == 0.001 && preserved.green == 203 && preserved.blue == 400);
    FO4HDR_CHECK(QuantizeR10Unorm(nan) == 0);
    FO4HDR_CHECK(QuantizeR10Unorm(infinity) == 1023);
    FO4HDR_CHECK(NormalizeR10Unorm(65535) == 1.0);
}

void TestSt2084ReferenceVectors()
{
    struct Reference
    {
        double nits;
        double encoded;
        std::uint16_t r10Code;
    };
    constexpr std::array<Reference, 12> references{{
        {0.0, 7.309559025783966e-7, 0},
        {0.001, 0.006302377054571391, 6},
        {0.01, 0.02148621379868528, 22},
        {0.1, 0.06233686566269587, 64},
        {1.0, 0.14994573210018022, 153},
        {80.0, 0.4858567653886785, 497},
        {100.0, 0.508078421517399, 520},
        {203.0, 0.5806888810416109, 594},
        {400.0, 0.6525785975630672, 668},
        {1000.0, 0.751827096247041, 769},
        {2000.0, 0.8274246448588193, 846},
        {10000.0, 1.0, 1023}
    }};

    double previous = -1.0;
    for (const auto& reference : references)
    {
        const auto encoded = EncodeSt2084Pq(reference.nits);
        FO4HDR_CHECK(test::Approx(encoded, reference.encoded, 1.0e-12));
        FO4HDR_CHECK(encoded >= previous);
        FO4HDR_CHECK(encoded >= 0.0 && encoded <= 1.0);
        const auto code = QuantizeR10Unorm(encoded);
        FO4HDR_CHECK(code == reference.r10Code);
        FO4HDR_CHECK(code <= 1023);
        FO4HDR_CHECK(
            std::abs(NormalizeR10Unorm(code) - encoded) <=
            0.5 / 1023.0 + 1.0e-12);
        previous = encoded;
    }

    FO4HDR_CHECK(EncodeSt2084Pq(-1.0) == EncodeSt2084Pq(0.0));
    FO4HDR_CHECK(EncodeSt2084Pq(20000.0) == 1.0);
    FO4HDR_CHECK(
        EncodeSt2084Pq(std::numeric_limits<double>::infinity()) == 1.0);
    FO4HDR_CHECK(
        EncodeSt2084Pq(std::numeric_limits<double>::quiet_NaN()) ==
        EncodeSt2084Pq(0.0));
    FO4HDR_CHECK(QuantizeR10Unorm(-1.0) == 0);
    FO4HDR_CHECK(QuantizeR10Unorm(2.0) == 1023);
}

void TestDeltaEItpReferenceVectors()
{
    struct Reference
    {
        LinearRgb reference;
        LinearRgb candidate;
        double expected;
    };
    constexpr std::array vectors{
        Reference{{100, 100, 100}, {101, 101, 101}, 0.7192686058769748},
        Reference{{100, 50, 25}, {101, 49, 26}, 3.1331495828677633},
        Reference{{92.24570899406527, 92.24570899406527, 92.24570899406527},
            {93.53771861465454, 93.53771861465454, 93.53771861465454}, 1.0},
        Reference{{0, 0, 0}, {0, 0, 0}, 0.0},
        Reference{{10000, 10000, 10000}, {10000, 10000, 10000}, 0.0}
    };
    for (const auto& vector : vectors)
    {
        const auto error = DeltaEItpBt2020Nits(vector.reference, vector.candidate);
        FO4HDR_CHECK(test::Approx(error, vector.expected, 1.0e-10));
        FO4HDR_CHECK(error == DeltaEItpBt2020Nits(vector.candidate, vector.reference));
        FO4HDR_CHECK(DeltaEItpBt2020Nits(vector.reference, vector.reference) == 0.0);
    }
}

void TestDeltaEItpInvalidInputs()
{
    constexpr LinearRgb valid{100, 50, 25};
    const auto infinity = std::numeric_limits<double>::infinity();
    const auto nan = std::numeric_limits<double>::quiet_NaN();
    for (const auto invalid : {-1.0, std::nextafter(10000.0, infinity),
             -infinity, infinity, nan})
    {
        for (const auto channel : {&LinearRgb::red, &LinearRgb::green, &LinearRgb::blue})
        {
            auto operand = valid;
            operand.*channel = invalid;
            FO4HDR_CHECK(DeltaEItpBt2020Nits(operand, valid) == infinity);
            FO4HDR_CHECK(DeltaEItpBt2020Nits(valid, operand) == infinity);
            FO4HDR_CHECK(DeltaEItpBt2020Nits(operand, operand) == infinity);
        }
    }
}

void TestOperatorLutQualityPercentiles()
{
    for (const auto count : {1U, 99U, 100U, 101U})
    {
        OperatorLutQualityMeasurements measurements;
        for (auto index = count; index > 0U; --index)
        {
            measurements.Record(static_cast<double>(index), OperatorLutQualityRegion::broad);
            measurements.Record(static_cast<double>(index) * 0.5,
                OperatorLutQualityRegion::holdout);
        }
        measurements.Record(200.0, OperatorLutQualityRegion::other);
        const auto summary = measurements.Summary();
        const auto expected = static_cast<double>(count - count / 100U);
        FO4HDR_CHECK(summary.available);
        FO4HDR_CHECK(summary.maximumDeltaEItp == 200.0);
        FO4HDR_CHECK(summary.broadP99DeltaEItp == expected);
        FO4HDR_CHECK(summary.holdoutP99DeltaEItp == expected * 0.5);
        FO4HDR_CHECK(summary.sampleCount == count * 2U + 1U);
        FO4HDR_CHECK(measurements.Summary().broadP99DeltaEItp == expected);
    }
}

void TestOperatorLutMaximumPolicy()
{
    struct Boundary
    {
        ProductionToneMapperAlgorithm algorithm;
        double nominal;
        double cutoff;
    };
    constexpr std::array boundaries{
        Boundary{ProductionToneMapperAlgorithm::aces2, 4.8, 4.85},
        Boundary{ProductionToneMapperAlgorithm::agX, 2.4, 2.45},
        Boundary{ProductionToneMapperAlgorithm::gt7, 2.4, 2.45}
    };
    const auto infinity = std::numeric_limits<double>::infinity();
    for (const auto boundary : boundaries)
    {
        FO4HDR_CHECK(OperatorLutMaximumDeltaEItp(boundary.algorithm) == boundary.nominal);
        OperatorLutQuality quality{true, boundary.nominal, 1.0, 1.0, 2U};
        FO4HDR_CHECK(quality.MeetsPracticalLimit(boundary.algorithm));
        quality.maximumDeltaEItp = std::nextafter(boundary.nominal, infinity);
        FO4HDR_CHECK(quality.MeetsPracticalLimit(boundary.algorithm));
        quality.maximumDeltaEItp = std::nextafter(boundary.cutoff, 0.0);
        FO4HDR_CHECK(quality.MeetsPracticalLimit(boundary.algorithm));
        quality.maximumDeltaEItp = boundary.cutoff;
        FO4HDR_CHECK(!quality.MeetsPracticalLimit(boundary.algorithm));
        quality.maximumDeltaEItp = std::nextafter(boundary.cutoff, infinity);
        FO4HDR_CHECK(!quality.MeetsPracticalLimit(boundary.algorithm));
    }
    const auto unknown = static_cast<ProductionToneMapperAlgorithm>(0xFF);
    FO4HDR_CHECK(OperatorLutMaximumDeltaEItp(unknown) == 0.0);
    const OperatorLutQuality zeroError{true, 0.0, 0.0, 0.0, 2U};
    FO4HDR_CHECK(!zeroError.MeetsPracticalLimit(unknown));
    FO4HDR_CHECK(!zeroError.MeetsFidelityGoal(unknown));
}

void TestOperatorLutQualityLimits()
{
    constexpr auto algorithm = ProductionToneMapperAlgorithm::gt7;
    OperatorLutQuality quality{true, OperatorLutMaximumDeltaEItp(algorithm),
        kOperatorLutPercentileDeltaEItp, kOperatorLutPercentileDeltaEItp, 2U};
    FO4HDR_CHECK(quality.MeetsPracticalLimit(algorithm));
    FO4HDR_CHECK(!quality.MeetsFidelityGoal(algorithm));
    const auto infinity = std::numeric_limits<double>::infinity();
    for (const auto field : {&OperatorLutQuality::broadP99DeltaEItp,
             &OperatorLutQuality::holdoutP99DeltaEItp})
    {
        auto exceeded = quality;
        exceeded.*field = std::nextafter(exceeded.*field, infinity);
        FO4HDR_CHECK(!exceeded.MeetsPracticalLimit(algorithm));
    }
    for (const auto field : {&OperatorLutQuality::maximumDeltaEItp,
             &OperatorLutQuality::broadP99DeltaEItp,
             &OperatorLutQuality::holdoutP99DeltaEItp})
    {
        auto invalid = quality;
        invalid.*field = std::numeric_limits<double>::quiet_NaN();
        FO4HDR_CHECK(!invalid.MeetsPracticalLimit(algorithm));
    }
    quality.maximumDeltaEItp = 1.0;
    FO4HDR_CHECK(quality.MeetsFidelityGoal(algorithm));
    quality.maximumDeltaEItp = std::nextafter(1.0, infinity);
    FO4HDR_CHECK(!quality.MeetsFidelityGoal(algorithm));
    quality.available = false;
    FO4HDR_CHECK(!quality.MeetsPracticalLimit(algorithm));
    quality.available = true;
    quality.sampleCount = 0U;
    FO4HDR_CHECK(!quality.MeetsPracticalLimit(algorithm));
}

void TestOperatorLutQualityInvalidMeasurements()
{
    OperatorLutQualityMeasurements empty;
    FO4HDR_CHECK(!empty.Summary().available);
    empty.Record(0.0, OperatorLutQualityRegion::broad);
    FO4HDR_CHECK(!empty.Summary().available);
    OperatorLutQualityMeasurements missingBroad;
    missingBroad.Record(0.0, OperatorLutQualityRegion::holdout);
    FO4HDR_CHECK(!missingBroad.Summary().available);
    const auto infinity = std::numeric_limits<double>::infinity();
    const auto nan = std::numeric_limits<double>::quiet_NaN();
    for (const auto invalid : {-1.0, -infinity, infinity, nan})
        for (const auto region : {OperatorLutQualityRegion::broad,
                 OperatorLutQualityRegion::holdout, OperatorLutQualityRegion::other})
        {
            OperatorLutQualityMeasurements measurements;
            measurements.Record(invalid, region);
            measurements.Record(0.0, OperatorLutQualityRegion::broad);
            measurements.Record(0.0, OperatorLutQualityRegion::holdout);
            FO4HDR_CHECK(!measurements.Summary().available);
        }
    FO4HDR_CHECK(!EvaluateOperatorLutQuality({}).available);
    std::atomic<std::uint64_t> generation{2U};
    FO4HDR_CHECK(!EvaluateOperatorLutQuality({}, {&generation, 1U}).available);
}

void TestWideGamutReadinessAndSdrHandoff()
{
    WideGamutResourceReadiness readiness{
        .replacementShaderSet = true,
        .presentationProxySet = true,
        .compositionSet = true,
        .uiSet = true,
        .outputSet = true
    };
    FO4HDR_CHECK(readiness.Complete());
    constexpr std::array partialSets{
        WideGamutResourceReadiness{false, true, true, true, true},
        WideGamutResourceReadiness{true, false, true, true, true},
        WideGamutResourceReadiness{true, true, false, true, true},
        WideGamutResourceReadiness{true, true, true, false, true},
        WideGamutResourceReadiness{true, true, true, true, false}
    };
    for (const auto partial : partialSets)
        FO4HDR_CHECK(!partial.Complete());
    FO4HDR_CHECK(IsWideGamutGenerationReady(readiness, 7, 7));
    FO4HDR_CHECK(!IsWideGamutGenerationReady(readiness, 0, 0));
    FO4HDR_CHECK(!IsWideGamutGenerationReady(readiness, 6, 7));
    FO4HDR_CHECK(!IsWideGamutGenerationReady(partialSets[0], 7, 7));

    FO4HDR_CHECK(DecideSdrHandoff(true, true,
        LinearColorDomain::linearBt2020UiRelative, true) ==
        SdrHandoffAction::none);
    FO4HDR_CHECK(DecideSdrHandoff(false, false,
        LinearColorDomain::unknown, false) == SdrHandoffAction::none);
    FO4HDR_CHECK(DecideSdrHandoff(false, true,
        LinearColorDomain::vanillaSdrCodes, true) ==
        SdrHandoffAction::copyVanillaSdr);
    FO4HDR_CHECK(DecideSdrHandoff(false, true,
        LinearColorDomain::vanillaSdrCodes, false) ==
        SdrHandoffAction::clearBlack);
    FO4HDR_CHECK(DecideSdrHandoff(false, true,
        LinearColorDomain::linearBt709Relative, true) ==
        SdrHandoffAction::clearBlack);
    FO4HDR_CHECK(DecideSdrHandoff(false, true,
        LinearColorDomain::linearBt2020UiRelative, true) ==
        SdrHandoffAction::clearBlack);
    FO4HDR_CHECK(DecideSdrHandoff(false, true,
        LinearColorDomain::encodedSrgbBt709UiRelative, true) ==
        SdrHandoffAction::clearBlack);
    FO4HDR_CHECK(DecideSdrHandoff(false, true,
        LinearColorDomain::unknown, true) ==
        SdrHandoffAction::clearBlackAndDisable);
}

void TestAboveWhiteSurvivesReferencePipeline()
{
    constexpr double referenceWhiteNits = 203.0;
    const auto whiteNits = ConvertBt709ToBt2020(
        {referenceWhiteNits, referenceWhiteNits, referenceWhiteNits});
    const auto highlightNits = ConvertBt709ToBt2020(
        {812.0, 812.0, 812.0});
    const auto whitePq = EncodeSt2084Pq(whiteNits);
    const auto highlightPq = EncodeSt2084Pq(highlightNits);

    FO4HDR_CHECK(highlightNits.red > referenceWhiteNits);
    FO4HDR_CHECK(highlightPq.red > whitePq.red);
    FO4HDR_CHECK(highlightPq.green > whitePq.green);
    FO4HDR_CHECK(highlightPq.blue > whitePq.blue);
    FO4HDR_CHECK(
        QuantizeR10Unorm(highlightPq.red) >
        QuantizeR10Unorm(whitePq.red));
}

void TestTemporalIntermediateRoundTrip()
{
    constexpr std::array samples{
        0.0, 0.001, 0.01, 0.18, 1.0, 2.0, 4.0, 8.0, 16.0,
        65504.0};
    double priorEncoded = -1.0;
    for (const auto sample : samples)
    {
        const auto encoded = EncodeTemporalIntermediate(sample);
        const auto decoded = DecodeTemporalIntermediate(encoded);
        FO4HDR_CHECK(std::isfinite(encoded));
        FO4HDR_CHECK(std::isfinite(decoded));
        FO4HDR_CHECK(encoded >= priorEncoded);
        FO4HDR_CHECK(encoded >= 0.0 && encoded <= 1.0);
        FO4HDR_CHECK(test::Approx(
            decoded, sample, std::max(1.0e-9, sample * 1.0e-9)));
        priorEncoded = encoded;
    }

    FO4HDR_CHECK(EncodeTemporalIntermediate(-1.0) == 0.0);
    FO4HDR_CHECK(DecodeTemporalIntermediate(-1.0) == 0.0);
    FO4HDR_CHECK(EncodeTemporalIntermediate(
        std::numeric_limits<double>::quiet_NaN()) == 0.0);
    FO4HDR_CHECK(DecodeTemporalIntermediate(
        std::numeric_limits<double>::quiet_NaN()) == 0.0);
    FO4HDR_CHECK(DecodeTemporalIntermediate(
        std::numeric_limits<double>::infinity()) == 65504.0);
}

void TestResourcePromotionPredicate()
{
    SceneResourceDescription eligible{
        .format = SceneResourceFormat::r11g11b10Float};
    for (const auto dimensions : std::array{
             std::pair{1920U, 1080U},
             std::pair{1440U, 810U},
             std::pair{960U, 540U}})
    {
        eligible.width = dimensions.first;
        eligible.height = dimensions.second;
        FO4HDR_CHECK(
            ShouldPromoteSceneResourceToFp16(eligible, 1920, 1080));
    }
    eligible.format = SceneResourceFormat::r16g16b16a16Float;
    FO4HDR_CHECK(!ShouldPromoteSceneResourceToFp16(eligible, 1920, 1080));
    eligible.format = SceneResourceFormat::other;
    FO4HDR_CHECK(!ShouldPromoteSceneResourceToFp16(eligible, 1920, 1080));
    eligible.format = SceneResourceFormat::r11g11b10Float;
    eligible.width = 1280;
    eligible.height = 800;
    FO4HDR_CHECK(!ShouldPromoteSceneResourceToFp16(eligible, 1920, 1080));
    eligible.width = 0;
    FO4HDR_CHECK(!ShouldPromoteSceneResourceToFp16(eligible, 1920, 1080));
}

D3D11_TEXTURE2D_DESC GameSceneTarget()
{
    D3D11_TEXTURE2D_DESC description{};
    description.Width = 1920;
    description.Height = 1080;
    description.MipLevels = 1;
    description.ArraySize = 1;
    description.Format = DXGI_FORMAT_R11G11B10_FLOAT;
    description.SampleDesc.Count = 1;
    description.Usage = D3D11_USAGE_DEFAULT;
    description.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;
    return description;
}

void TestSceneTexturePromotionGate()
{
    FO4HDR_CHECK(IsSceneTexturePromotionCandidate(GameSceneTarget(), false, 1920, 1080));
    FO4HDR_CHECK(!IsSceneTexturePromotionCandidate(GameSceneTarget(), true, 1920, 1080));
    for (const auto usage : std::array{
             D3D11_USAGE_IMMUTABLE, D3D11_USAGE_DYNAMIC, D3D11_USAGE_STAGING})
    {
        auto description = GameSceneTarget();
        description.Usage = usage;
        FO4HDR_CHECK(!IsSceneTexturePromotionCandidate(description, false, 1920, 1080));
    }
    auto cpuVisible = GameSceneTarget();
    cpuVisible.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
    FO4HDR_CHECK(!IsSceneTexturePromotionCandidate(cpuVisible, false, 1920, 1080));
    auto sampledOnly = GameSceneTarget();
    sampledOnly.BindFlags = D3D11_BIND_SHADER_RESOURCE | D3D11_BIND_UNORDERED_ACCESS;
    FO4HDR_CHECK(!IsSceneTexturePromotionCandidate(sampledOnly, false, 1920, 1080));
    for (const auto flag : std::array<UINT, 4>{D3D11_RESOURCE_MISC_SHARED,
             D3D11_RESOURCE_MISC_SHARED_KEYEDMUTEX, D3D11_RESOURCE_MISC_SHARED_NTHANDLE,
             D3D11_RESOURCE_MISC_GDI_COMPATIBLE})
    {
        auto description = GameSceneTarget();
        description.MiscFlags = flag;
        FO4HDR_CHECK(!IsSceneTexturePromotionCandidate(description, false, 1920, 1080));
    }
    auto mipmapped = GameSceneTarget();
    mipmapped.MiscFlags = D3D11_RESOURCE_MISC_GENERATE_MIPS;
    FO4HDR_CHECK(IsSceneTexturePromotionCandidate(mipmapped, false, 1920, 1080));
    auto fp16 = GameSceneTarget();
    fp16.Format = DXGI_FORMAT_R16G16B16A16_FLOAT;
    FO4HDR_CHECK(!IsSceneTexturePromotionCandidate(fp16, false, 1920, 1080));
    FO4HDR_CHECK(!IsSceneTexturePromotionCandidate(GameSceneTarget(), false, 1280, 1024));
    FO4HDR_CHECK(!IsSceneTexturePromotionCandidate(GameSceneTarget(), false, 0, 0));
}

void TestPromotionCallerImage()
{
    std::array<std::byte, 16> image{};
    const std::span<const std::byte> view(image);
    FO4HDR_CHECK(ImageContains(view, image.data()));
    FO4HDR_CHECK(ImageContains(view, image.data() + 15));
    FO4HDR_CHECK(!ImageContains(view, image.data() + 16));
    FO4HDR_CHECK(!ImageContains(view, nullptr));
    FO4HDR_CHECK(!ImageContains({}, image.data()));
}

HdrPathCapabilities AllCapabilities()
{
    return {
        .runtimeAuthorized = true,
        .signalContractReady = true,
        .fp16WorkingImage = true,
        .r10g10b10a2Presentation = true,
        .flipModel = true,
        .bufferCount = 2,
        .pqBt2020PresentSupported = true,
        .pqBt2020Applied = true,
        .resourcesReady = true,
        .productionToneMapperReady = false
    };
}

void TestActivationPolicy()
{
    auto capabilities = AllCapabilities();
    HdrActivationRequest developer{
        .enabled = true,
        .developerMode = true,
        .developerReferenceRequested = true
    };
    auto decision = DecideHdrActivation(developer, capabilities);
    FO4HDR_CHECK(decision.hdrActive);
    FO4HDR_CHECK(!decision.production);
    FO4HDR_CHECK(
        decision.mode == HdrActivationMode::developerReferenceHdr10);

    developer.developerMode = false;
    decision = DecideHdrActivation(developer, capabilities);
    FO4HDR_CHECK(!decision.hdrActive);
    FO4HDR_CHECK(
        decision.reason == HdrActivationReason::developerModeRequired);

    HdrActivationRequest production{
        .enabled = true,
        .productionRequested = true
    };
    decision = DecideHdrActivation(production, capabilities);
    FO4HDR_CHECK(!decision.hdrActive);
    FO4HDR_CHECK(
        decision.reason ==
        HdrActivationReason::productionToneMapperUnavailable);
    capabilities.productionToneMapperReady = true;
    decision = DecideHdrActivation(production, capabilities);
    FO4HDR_CHECK(decision.hdrActive);
    FO4HDR_CHECK(decision.production);
}

void TestActivationCapabilityRequirements()
{
    struct Requirement
    {
        bool HdrPathCapabilities::*available;
        HdrActivationReason reason;
    };
    constexpr std::array requirements{
        Requirement{&HdrPathCapabilities::pqBt2020PresentSupported,
            HdrActivationReason::colorSpaceUnsupported},
        Requirement{&HdrPathCapabilities::pqBt2020Applied,
            HdrActivationReason::colorSpaceApplicationFailed},
        Requirement{&HdrPathCapabilities::r10g10b10a2Presentation,
            HdrActivationReason::presentationFormatUnavailable},
        Requirement{&HdrPathCapabilities::fp16WorkingImage,
            HdrActivationReason::workingFormatUnavailable},
        Requirement{&HdrPathCapabilities::signalContractReady,
            HdrActivationReason::signalContractNotReady},
        Requirement{&HdrPathCapabilities::runtimeAuthorized,
            HdrActivationReason::runtimeUnauthorized},
        Requirement{&HdrPathCapabilities::flipModel,
            HdrActivationReason::flipModelRequired},
        Requirement{&HdrPathCapabilities::resourcesReady,
            HdrActivationReason::resourcesUnavailable}
    };
    constexpr HdrActivationRequest request{
        .enabled = true,
        .developerMode = true,
        .developerReferenceRequested = true
    };
    for (const auto& requirement : requirements) {
        auto capabilities = AllCapabilities();
        capabilities.*(requirement.available) = false;
        const auto decision = DecideHdrActivation(request, capabilities);
        FO4HDR_CHECK(!decision.hdrActive);
        FO4HDR_CHECK(decision.reason == requirement.reason);
    }

    auto capabilities = AllCapabilities();
    capabilities.bufferCount = 1;
    const auto decision = DecideHdrActivation(request, capabilities);
    FO4HDR_CHECK(
        decision.reason == HdrActivationReason::insufficientBufferCount);
}

void TestDeviceCreationBypass()
{
    FO4HDR_CHECK(DeviceCreationBypassed(true, 0, true));
    // Before the engine owns a device, no creation is expected yet.
    FO4HDR_CHECK(!DeviceCreationBypassed(true, 0, false));
    FO4HDR_CHECK(!DeviceCreationBypassed(true, 1, true));
    FO4HDR_CHECK(!DeviceCreationBypassed(false, 0, true));
}

void TestHdrCandidateDecision()
{
    constexpr HdrCandidateInputs accepted{.displayHdr10 = true, .facadeRequired = true,
        .facadeDescriptorSupported = true};
    FO4HDR_CHECK(DecideHdrCandidate(accepted) == HdrCandidateDecision::attempt);
    // An SDR or undiscovered display fails the post-creation check, so no candidate is made.
    auto inputs = accepted;
    inputs.displayHdr10 = false;
    FO4HDR_CHECK(DecideHdrCandidate(inputs) == HdrCandidateDecision::displayNotHdr10);
    inputs = accepted;
    inputs.facadeDescriptorSupported = false;
    FO4HDR_CHECK(DecideHdrCandidate(inputs) == HdrCandidateDecision::descriptorUnsupported);
    // The developer reference path presents without the application facade.
    inputs.facadeRequired = false;
    FO4HDR_CHECK(DecideHdrCandidate(inputs) == HdrCandidateDecision::attempt);
    // ENB keeps SDR whatever the display or descriptor allow.
    inputs = accepted;
    inputs.enbDetected = true;
    FO4HDR_CHECK(DecideHdrCandidate(inputs) == HdrCandidateDecision::enbDetected);
    FO4HDR_CHECK(DecideHdrCandidate({.enbDetected = true}) == HdrCandidateDecision::enbDetected);
    FO4HDR_CHECK(DecideHdrCandidate({.facadeRequired = true}) ==
        HdrCandidateDecision::displayNotHdr10);
}

void TestHeartbeatFrameQualification(PipelineHeartbeat& heartbeat)
{
    heartbeat.BeginFrame(1, 2);
    heartbeat.Observe(RenoDxShaderPass::toneMapNewB);
    heartbeat.Observe(RenoDxShaderPass::lut);
    const auto evaluation = heartbeat.Evaluate(1, 2);
    FO4HDR_CHECK(evaluation.ready);
    FO4HDR_CHECK(evaluation.ordered);
    FO4HDR_CHECK(
        evaluation.outcome == PipelineHeartbeatEvaluation::Outcome::ready);
    FO4HDR_CHECK(
        DecidePipelineHeartbeatAction(evaluation) ==
        PipelineHeartbeatAction::renderHdr);
    FO4HDR_CHECK(
        DecideTemporalSceneAction(evaluation, {false, true, true, false}) ==
        TemporalSceneAction::ignoreUnqualifiedBranch);
    FO4HDR_CHECK(
        DecideTemporalSceneAction(evaluation, {true, false, true, false}) ==
        TemporalSceneAction::ignoreUnqualifiedBranch);
    FO4HDR_CHECK(
        DecideTemporalSceneAction(evaluation, {true, true, false, false}) ==
        TemporalSceneAction::ignoreUnqualifiedBranch);
    FO4HDR_CHECK(
        DecideTemporalSceneAction(evaluation, {true, true, true, false}) ==
        TemporalSceneAction::rejectMissingProxy);
    FO4HDR_CHECK(
        DecideTemporalSceneAction(evaluation, {true, true, true, true}) ==
        TemporalSceneAction::acceptProxy);
    FO4HDR_CHECK(
        DecideTemporalSceneAction(evaluation, {true, true, false, false, true}) ==
        TemporalSceneAction::acceptInternalScene);
    FO4HDR_CHECK(
        DecideTemporalSceneAction(evaluation, {false, true, false, false, true}) ==
        TemporalSceneAction::ignoreUnqualifiedBranch);
    FO4HDR_CHECK(
        DecideTemporalSceneAction(evaluation, {true, false, false, false, true}) ==
        TemporalSceneAction::ignoreUnqualifiedBranch);
    FO4HDR_CHECK(
        DecideTemporalSceneAction(evaluation, {true, true, true, false, true}) ==
        TemporalSceneAction::rejectMissingProxy);
    FO4HDR_CHECK(
        heartbeat.Evaluate(2, 2).outcome ==
        PipelineHeartbeatEvaluation::Outcome::staleGeneration);
    FO4HDR_CHECK(
        DecidePipelineHeartbeatAction(heartbeat.Evaluate(2, 2)) ==
        PipelineHeartbeatAction::disableGeneration);
    FO4HDR_CHECK(
        heartbeat.Evaluate(1, 3).outcome ==
        PipelineHeartbeatEvaluation::Outcome::staleFrame);
    for (const auto stale : {heartbeat.Evaluate(2, 2), heartbeat.Evaluate(1, 3)})
        FO4HDR_CHECK(DecideTemporalSceneAction(stale, {true, true, false, false, true}) ==
            TemporalSceneAction::ignoreUnqualifiedBranch);
}

void TestOrderedHeartbeat()
{
    PipelineHeartbeat heartbeat;
    heartbeat.Reset(1);
    heartbeat.BeginFrame(1, 1);
    auto evaluation = heartbeat.Evaluate(1, 1);
    FO4HDR_CHECK(
        DecidePipelineHeartbeatAction(evaluation) ==
        PipelineHeartbeatAction::waitInSdr);
    heartbeat.Observe(RenoDxShaderPass::taa);
    evaluation = heartbeat.Evaluate(1, 1);
    FO4HDR_CHECK(
        DecideTemporalSceneAction(evaluation, {true, true, true, false}) ==
        TemporalSceneAction::ignoreUnqualifiedBranch);
    FO4HDR_CHECK(
        DecideTemporalSceneAction(evaluation, {true, true, false, false, true}) ==
        TemporalSceneAction::ignoreUnqualifiedBranch);
    heartbeat.Observe(RenoDxShaderPass::lut);
    evaluation = heartbeat.Evaluate(1, 1);
    FO4HDR_CHECK(!evaluation.ready);
    FO4HDR_CHECK(evaluation.lutObserved);
    FO4HDR_CHECK(!evaluation.toneMapFamilyObserved);
    FO4HDR_CHECK(
        evaluation.outcome ==
        PipelineHeartbeatEvaluation::Outcome::incomplete);
    FO4HDR_CHECK(
        DecidePipelineHeartbeatAction(evaluation) ==
        PipelineHeartbeatAction::waitInSdr);
    heartbeat.Observe(RenoDxShaderPass::toneMapA);
    evaluation = heartbeat.Evaluate(1, 1);
    FO4HDR_CHECK(!evaluation.ready);
    FO4HDR_CHECK(!evaluation.ordered);
    FO4HDR_CHECK(
        evaluation.outcome ==
        PipelineHeartbeatEvaluation::Outcome::incomplete);
    FO4HDR_CHECK(
        DecidePipelineHeartbeatAction(evaluation) ==
        PipelineHeartbeatAction::waitInSdr);
    heartbeat.Observe(RenoDxShaderPass::lut);
    evaluation = heartbeat.Evaluate(1, 1);
    FO4HDR_CHECK(evaluation.ready);
    FO4HDR_CHECK(evaluation.ordered);

    TestHeartbeatFrameQualification(heartbeat);

    heartbeat.BeginFrame(1, 3);
    heartbeat.Observe(RenoDxShaderPass::toneMapA);
    heartbeat.Observe(RenoDxShaderPass::toneMapB);
    heartbeat.Observe(RenoDxShaderPass::lut);
    FO4HDR_CHECK(
        heartbeat.Evaluate(1, 3).outcome ==
        PipelineHeartbeatEvaluation::Outcome::ready);

    heartbeat.BeginFrame(1, 4);
    heartbeat.Observe(RenoDxShaderPass::toneMapA);
    heartbeat.Observe(RenoDxShaderPass::lut);
    heartbeat.Observe(RenoDxShaderPass::toneMapB);
    FO4HDR_CHECK(
        heartbeat.Evaluate(1, 4).outcome ==
        PipelineHeartbeatEvaluation::Outcome::ready);
}

void TestRendererPauseAndSdr(HdrRendererLifecycle& lifecycle)
{
    FO4HDR_CHECK(lifecycle.BindDeviceAndSwapChain());
    FO4HDR_CHECK(lifecycle.PublishHdrResources());
    const auto publishedGeneration =
        lifecycle.Snapshot().resourceGeneration;
    FO4HDR_CHECK(lifecycle.PauseHdrPresentation());
    FO4HDR_CHECK(lifecycle.Snapshot().resourcesPublished);
    FO4HDR_CHECK(!lifecycle.Snapshot().hdrActive);
    FO4HDR_CHECK(
        lifecycle.Snapshot().resourceGeneration == publishedGeneration);
    FO4HDR_CHECK(lifecycle.ResumeHdrPresentation());
    FO4HDR_CHECK(lifecycle.Snapshot().hdrActive);
    FO4HDR_CHECK(lifecycle.DeactivateToSdr());
    FO4HDR_CHECK(!lifecycle.Snapshot().resourcesPublished);
    const auto sdrGeneration = lifecycle.Snapshot().resourceGeneration;
    FO4HDR_CHECK(lifecycle.DeactivateToSdr());
    FO4HDR_CHECK(
        lifecycle.Snapshot().resourceGeneration == sdrGeneration);
    FO4HDR_CHECK(lifecycle.PublishHdrResources());
}

void TestRendererRepeatedResets(HdrRendererLifecycle& lifecycle)
{
    auto prior = lifecycle.Snapshot();
    for (std::uint32_t iteration = 0; iteration < 10000; ++iteration)
    {
        const auto resetEpoch = static_cast<std::uint64_t>(iteration) + 1;
        const auto beforeResetGeneration =
            lifecycle.Snapshot().resourceGeneration;
        FO4HDR_CHECK(lifecycle.OnGameReset(resetEpoch));
        FO4HDR_CHECK(
            lifecycle.Snapshot().gameResetEpoch == resetEpoch);
        FO4HDR_CHECK(lifecycle.Snapshot().resourcesPublished);
        FO4HDR_CHECK(!lifecycle.Snapshot().hdrActive);
        FO4HDR_CHECK(
            lifecycle.Snapshot().resourceGeneration >
            beforeResetGeneration);
        const auto afterResetGeneration =
            lifecycle.Snapshot().resourceGeneration;
        FO4HDR_CHECK(!lifecycle.OnGameReset(resetEpoch));
        FO4HDR_CHECK(
            lifecycle.Snapshot().resourceGeneration ==
            afterResetGeneration);
        const auto oldResourceGeneration =
            lifecycle.Snapshot().resourceGeneration;
        FO4HDR_CHECK(lifecycle.BeginResize());
        FO4HDR_CHECK(!lifecycle.Snapshot().resourcesPublished);
        FO4HDR_CHECK(!lifecycle.Snapshot().hdrActive);
        FO4HDR_CHECK(
            !lifecycle.IsCurrentResourceGeneration(oldResourceGeneration));
        FO4HDR_CHECK(lifecycle.CompleteResize(true, true));
        const auto current = lifecycle.Snapshot();
        FO4HDR_CHECK(current.state == HdrRendererState::hdr10Ready);
        FO4HDR_CHECK(current.resourcesPublished);
        FO4HDR_CHECK(current.hdrActive);
        FO4HDR_CHECK(current.swapChainGeneration > prior.swapChainGeneration);
        FO4HDR_CHECK(current.resourceGeneration > prior.resourceGeneration);
        FO4HDR_CHECK(
            lifecycle.IsCurrentResourceGeneration(
                current.resourceGeneration));
        prior = current;

        lifecycle.OnDisplayChange();
        FO4HDR_CHECK(
            lifecycle.Snapshot().state == HdrRendererState::vanillaSdr);
        FO4HDR_CHECK(!lifecycle.Snapshot().resourcesPublished);
        FO4HDR_CHECK(lifecycle.PublishHdrResources());

        const auto deviceResourceGeneration =
            lifecycle.Snapshot().resourceGeneration;
        lifecycle.OnDeviceLost();
        FO4HDR_CHECK(
            lifecycle.Snapshot().state == HdrRendererState::deviceLost);
        FO4HDR_CHECK(!lifecycle.Snapshot().resourcesPublished);
        FO4HDR_CHECK(
            !lifecycle.IsCurrentResourceGeneration(
                deviceResourceGeneration));
        FO4HDR_CHECK(lifecycle.BindDeviceAndSwapChain());
        FO4HDR_CHECK(lifecycle.PublishHdrResources());
        prior = lifecycle.Snapshot();
    }
}

void TestRendererLifecycleStress()
{
    HdrRendererLifecycle lifecycle;
    TestRendererPauseAndSdr(lifecycle);
    TestRendererRepeatedResets(lifecycle);
    lifecycle.OnDeviceLost();
    FO4HDR_CHECK(lifecycle.Snapshot().state == HdrRendererState::deviceLost);
    FO4HDR_CHECK(!lifecycle.Snapshot().resourcesPublished);
    const auto lostGeneration = lifecycle.Snapshot().resourceGeneration;
    lifecycle.OnDeviceLost();
    FO4HDR_CHECK(
        lifecycle.Snapshot().resourceGeneration == lostGeneration);
    FO4HDR_CHECK(lifecycle.BindDeviceAndSwapChain());
    FO4HDR_CHECK(lifecycle.Snapshot().state == HdrRendererState::vanillaSdr);
    FO4HDR_CHECK(lifecycle.PublishHdrResources());
    FO4HDR_CHECK(lifecycle.BeginResize());
    FO4HDR_CHECK(!lifecycle.CompleteResize(false, false));
    FO4HDR_CHECK(
        lifecycle.Snapshot().state == HdrRendererState::vanillaSdr);
    FO4HDR_CHECK(!lifecycle.Snapshot().resourcesPublished);
    lifecycle.OnDeviceLost();
    FO4HDR_CHECK(lifecycle.Snapshot().state == HdrRendererState::deviceLost);
}

void TestGraphicsLifecyclePublication()
{
    GraphicsLifecyclePublisher publisher;
    auto publication = publisher.Read();
    FO4HDR_CHECK(!publication.gameplayReady);
    FO4HDR_CHECK(!publication.presentationBlocked);
    FO4HDR_CHECK(publication.resetEpoch == 0);

    publication = publisher.Publish(true, false);
    FO4HDR_CHECK(publication.gameplayReady);
    FO4HDR_CHECK(!publication.presentationBlocked);
    FO4HDR_CHECK(publication.resetEpoch == 0);
    const auto unchanged = publisher.Publish(true, false);
    FO4HDR_CHECK(unchanged.gameplayReady);
    FO4HDR_CHECK(unchanged.resetEpoch == 0);

    publication = publisher.Publish(false, true);
    FO4HDR_CHECK(!publication.gameplayReady);
    FO4HDR_CHECK(publication.resetEpoch == 1);
    publication = publisher.Publish(true, false);
    FO4HDR_CHECK(publication.gameplayReady);
    FO4HDR_CHECK(publication.resetEpoch == 1);

    publication = publisher.PublishPresentationBlocked(true);
    FO4HDR_CHECK(publication.gameplayReady);
    FO4HDR_CHECK(publication.presentationBlocked);
    FO4HDR_CHECK(publication.resetEpoch == 1);
    publication = publisher.Publish(false, false);
    FO4HDR_CHECK(!publication.gameplayReady);
    FO4HDR_CHECK(publication.presentationBlocked);
    publication = publisher.PublishPresentationBlocked(false);
    FO4HDR_CHECK(!publication.gameplayReady);
    FO4HDR_CHECK(!publication.presentationBlocked);
    publication = publisher.Publish(true, false);

    for (std::uint64_t reset = 2; reset <= 10001; ++reset)
    {
        // Repeated NewGame-style readiness must still advance the epoch.
        publication = publisher.Publish(true, true);
        FO4HDR_CHECK(publication.gameplayReady);
        FO4HDR_CHECK(!publication.presentationBlocked);
        FO4HDR_CHECK(publication.resetEpoch == reset);
        const auto observed = publisher.Read();
        FO4HDR_CHECK(observed.gameplayReady);
        FO4HDR_CHECK(observed.resetEpoch == reset);
    }
    const auto finalEpoch = publication.resetEpoch;
    publication = publisher.Publish(false, false);
    FO4HDR_CHECK(!publication.gameplayReady);
    FO4HDR_CHECK(publication.resetEpoch == finalEpoch);

    HdrRendererLifecycle retirement;
    FO4HDR_CHECK(retirement.BindDeviceAndSwapChain());
    FO4HDR_CHECK(retirement.PublishHdrResources());
    const auto published = retirement.Snapshot().resourceGeneration;
    retirement.Detach();
    FO4HDR_CHECK(!retirement.Snapshot().resourcesPublished);
    FO4HDR_CHECK(!retirement.IsCurrentResourceGeneration(published));
    const auto detached = retirement.Snapshot().resourceGeneration;
    retirement.Detach();
    FO4HDR_CHECK(retirement.Snapshot().resourceGeneration == detached);

    FO4HDR_CHECK(retirement.BindDeviceAndSwapChain());
    FO4HDR_CHECK(retirement.PublishHdrResources());
    const auto republished = retirement.Snapshot().resourceGeneration;
    retirement.Disable();
    FO4HDR_CHECK(!retirement.Snapshot().resourcesPublished);
    FO4HDR_CHECK(!retirement.IsCurrentResourceGeneration(republished));
    const auto disabled = retirement.Snapshot().resourceGeneration;
    retirement.Disable();
    FO4HDR_CHECK(retirement.Snapshot().resourceGeneration == disabled);
}

void TestDeveloperConfiguration()
{
    constexpr std::string_view enabled = R"ini(
[General]
DeveloperMode=1
[Debug]
TraceRenderPipeline=0
DeveloperHdr10Reference=1
ShowDeveloperOverlay=1
ForceHdrSwapChainFailure=0
)ini";
    auto parsed = ParsePluginConfiguration(enabled);
    FO4HDR_CHECK(parsed.valid);
    FO4HDR_CHECK(parsed.value.developerHdr10Reference);
    FO4HDR_CHECK(parsed.value.showDeveloperOverlay);
    FO4HDR_CHECK(!parsed.value.forceHdrSwapChainFailure);

    constexpr std::string_view overlayWithoutReference = R"ini(
[General]
DeveloperMode=1
[Debug]
TraceRenderPipeline=0
DeveloperHdr10Reference=0
ShowDeveloperOverlay=1
ForceHdrSwapChainFailure=0
)ini";
    parsed = ParsePluginConfiguration(overlayWithoutReference);
    FO4HDR_CHECK(!parsed.valid);
    FO4HDR_CHECK(
        parsed.error ==
        PluginConfigurationError::invalidCombination);

    constexpr std::string_view referenceWithoutDeveloper = R"ini(
[General]
DeveloperMode=0
[Debug]
TraceRenderPipeline=0
DeveloperHdr10Reference=1
ShowDeveloperOverlay=0
ForceHdrSwapChainFailure=0
)ini";
    parsed = ParsePluginConfiguration(referenceWithoutDeveloper);
    FO4HDR_CHECK(!parsed.valid);
    FO4HDR_CHECK(
        parsed.error ==
        PluginConfigurationError::invalidCombination);

    constexpr std::string_view failureWithoutReference = R"ini(
[General]
DeveloperMode=1
[Debug]
TraceRenderPipeline=0
DeveloperHdr10Reference=0
ShowDeveloperOverlay=0
ForceHdrSwapChainFailure=1
)ini";
    parsed = ParsePluginConfiguration(failureWithoutReference);
    FO4HDR_CHECK(!parsed.valid);
    FO4HDR_CHECK(
        parsed.error ==
        PluginConfigurationError::invalidCombination);
}

}  // namespace

void RunHdrCoreTests()
{
    TestBt709ToBt2020();
    TestDisplayStandardsOracle();
    TestDisplaySignalContainment();
    TestSt2084ReferenceVectors();
    TestDeltaEItpReferenceVectors();
    TestDeltaEItpInvalidInputs();
    TestOperatorLutQualityPercentiles();
    TestOperatorLutMaximumPolicy();
    TestOperatorLutQualityLimits();
    TestOperatorLutQualityInvalidMeasurements();
    TestWideGamutReadinessAndSdrHandoff();
    TestAboveWhiteSurvivesReferencePipeline();
    TestTemporalIntermediateRoundTrip();
    TestResourcePromotionPredicate();
    TestSceneTexturePromotionGate();
    TestPromotionCallerImage();
    TestActivationPolicy();
    TestActivationCapabilityRequirements();
    TestDeviceCreationBypass();
    TestHdrCandidateDecision();
    TestOrderedHeartbeat();
    TestRendererLifecycleStress();
    TestGraphicsLifecyclePublication();
    TestDeveloperConfiguration();
}

}  // namespace fo4hdr::tests
