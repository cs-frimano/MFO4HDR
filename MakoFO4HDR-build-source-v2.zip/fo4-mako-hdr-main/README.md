<!-- SPDX-FileCopyrightText: FO4Isotope contributors -->
<!-- SPDX-License-Identifier: LicenseRef-FO4Isotope-GPL-3.0-or-later-with-CommonLibF4-Exceptions -->

# MakoFO4HDR

MakoFO4HDR is a standalone Fallout 4 F4SE plugin that follows MAKO Decky's per-game HDR toggle. When MAKO HDR is on, the plugin takes over Fallout 4's D3D11/DXGI output and produces HDR10 output for DXVK/Gamescope. When MAKO HDR is off, the plugin leaves the game's presentation in SDR. It does not require an entry in Fallout 4's Mods menu or MCM; open its controls with **Alt+H**.

The HDR rendering implementation is derived from FO4Isotope and remains under its GPL-3.0-or-later license with CommonLibF4 exceptions. This project has a separate F4SE identity, settings file, log, MAKO environment gate, and a zero-bloom SteamOS default for the black-bloom issue reported in Proton. See `THIRD_PARTY_NOTICES.md` and `LICENSES/` for attribution and license terms.

## MAKO integration

Launch Fallout 4 with MAKO Decky's usual wrapper:

```text
/home/deck/.local/bin/mako-run %command%
```

In the Fallout 4 profile, enable **Enable HDR (Restart)** and keep **Gamescope WSI** off. MAKO sets `MAKO_DISABLE_HDR_EXPOSURE=0` and `DXVK_HDR=1` for that launch. MakoFO4HDR requires both values before it attempts HDR, so the F4SE plugin follows the Decky restart toggle instead of independently forcing HDR. It still verifies DXVK's PQ/BT.2020 swap-chain support and HDR/SDR color-space transitions before presenting HDR.

For complete SteamOS install and troubleshooting steps, see [STEAMOS-MAKO.md](STEAMOS-MAKO.md).

## Install

Install F4SE for the selected Fallout 4 runtime. After building on Windows x64 and copying the project package to SteamOS, install directly into the game with `bash scripts/install-steamos.sh --game-root "/path/to/Fallout 4"`. For Mod Organizer 2, use `bash scripts/install-steamos.sh --mo2-mod "/path/to/MO2/mods/MakoFO4HDR"`, then enable that mod in MO2. The installer copies the DLL and creates the INI only if one does not already exist. Remove or disable FO4Isotope and other D3D11 HDR/tonemapping plugins; they hook the same renderer and cannot safely run together. The log is written to `Documents/My Games/Fallout4/F4SE/MakoFO4HDR.log` inside the Proton prefix.

The plugin has no MAKO Decky UI entry and does not modify MAKO files. MAKO controls whether the output path is eligible through its launch environment. Fallout 4 and MakoFO4HDR must both be restarted after changing the per-game HDR toggle.

## Build

MakoFO4HDR uses C++23, XMake, MSVC, and Dear-Modding-FO4 CommonLibF4 on Windows x64. Use the tool versions recorded in `versions.lock.json`. From PowerShell 7 in the Visual Studio x64 Native Tools environment:

```powershell
git -c core.autocrlf=false -c core.eol=lf submodule update --init --recursive -- lib/commonlibf4
.\scripts\bootstrap.ps1
.\scripts\build.ps1 -Mode debug
```

The staged plugin is under `dist/universal/Data/F4SE/Plugins/`. The runtime profiles in this source have not been validated on every listed Fallout 4 version; the workflow permits building those profiles but does not claim they were tested in game.

### Build it with GitHub Actions

1. Put this project in a GitHub repository. Include the project files and `.github/workflows/build-plugin.yml`; the workflow fetches the pinned CommonLibF4 source itself.
2. Open the repository's **Actions** tab, select **Build MakoFO4HDR**, and choose **Run workflow**.
3. When the run finishes, open it and download the **MakoFO4HDR-Windows-x64** artifact.
4. Extract the artifact on the Deck and install it with `bash scripts/install-steamos.sh --payload "/path/to/extracted/Plugins" --game-root "/path/to/Fallout 4"` (or use `--mo2-mod` for a Mod Organizer 2 mod folder).

The job builds on a Windows x64 runner and uploads the installable files for 14 days. This source archive does not contain a compiled DLL. GitHub Actions availability and quotas depend on the repository visibility and account plan.

## License

Licensed under **GPL-3.0-or-later with the CommonLibF4 exceptions**. See the [combined license](LICENSES/LicenseRef-FO4Isotope-GPL-3.0-or-later-with-CommonLibF4-Exceptions.txt). Third-party files retain their own notices and licenses.
