#!/usr/bin/env bash
set -euo pipefail

usage() {
    cat <<'EOF'
Install a built MakoFO4HDR plugin on SteamOS.

Usage:
  bash scripts/install-steamos.sh --game-root PATH [--payload PATH]
  bash scripts/install-steamos.sh --mo2-mod PATH [--payload PATH]

The payload directory must contain MakoFO4HDR.dll and MakoFO4HDR.ini. It
defaults to dist/universal/Data/F4SE/Plugins in this source checkout.
EOF
}

mode=""
destination=""
payload=""

while (($#)); do
    case "$1" in
        --game-root|--mo2-mod)
            if (($# < 2)) || [[ -n "$mode" ]]; then
                usage >&2
                exit 2
            fi
            mode="$1"
            destination="$2"
            shift 2
            ;;
        --payload)
            if (($# < 2)) || [[ -n "$payload" ]]; then
                usage >&2
                exit 2
            fi
            payload="$2"
            shift 2
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            usage >&2
            exit 2
            ;;
    esac
done

if [[ -z "$mode" || -z "$destination" ]]; then
    usage >&2
    exit 2
fi

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
project_root="$(cd -- "$script_dir/.." && pwd)"
if [[ -z "$payload" ]]; then
    payload="$project_root/dist/universal/Data/F4SE/Plugins"
fi

for file in MakoFO4HDR.dll MakoFO4HDR.ini; do
    if [[ ! -f "$payload/$file" ]]; then
        printf 'Missing installer payload: %s\n' "$payload/$file" >&2
        printf 'Build MakoFO4HDR on Windows x64 first, or pass --payload PATH.\n' >&2
        exit 1
    fi
done

case "$mode" in
    --game-root)
        if [[ ! -f "$destination/Fallout4.exe" || ! -d "$destination/Data" ]]; then
            printf 'Not a Fallout 4 install directory: %s\n' "$destination" >&2
            exit 1
        fi
        target="$destination/Data/F4SE/Plugins"
        ;;
    --mo2-mod)
        target="$destination/Data/F4SE/Plugins"
        ;;
esac

mkdir -p -- "$target"
tmp_dll="$target/.MakoFO4HDR.dll.tmp.$$"
tmp_ini="$target/.MakoFO4HDR.ini.tmp.$$"
trap 'rm -f -- "$tmp_dll" "$tmp_ini"' EXIT

cp -- "$payload/MakoFO4HDR.dll" "$tmp_dll"
chmod 0644 "$tmp_dll"
mv -f -- "$tmp_dll" "$target/MakoFO4HDR.dll"

if [[ -e "$target/MakoFO4HDR.ini" ]]; then
    printf 'Kept existing settings: %s\n' "$target/MakoFO4HDR.ini"
else
    cp -- "$payload/MakoFO4HDR.ini" "$tmp_ini"
    chmod 0644 "$tmp_ini"
    mv -- "$tmp_ini" "$target/MakoFO4HDR.ini"
    printf 'Installed default settings: %s\n' "$target/MakoFO4HDR.ini"
fi

printf 'Installed MakoFO4HDR.dll: %s\n' "$target/MakoFO4HDR.dll"
printf 'Enable MAKO HDR for the Fallout 4 profile and restart the game.\n'
