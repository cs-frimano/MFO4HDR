# SPDX-License-Identifier: LicenseRef-FO4Isotope-GPL-3.0-or-later-with-CommonLibF4-Exceptions
[CmdletBinding()]
param(
    [ValidateSet("debug", "releasedbg")]
    [string]$Mode = "debug",

    [switch]$AllowUnvalidatedRuntime,

    [switch]$DisablePch,

    [switch]$DisableFrameTrace
)

$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "internal/Project.Common.ps1")

& (Join-Path $PSScriptRoot "configure.ps1") `
    -Mode $Mode `
    -AllowUnvalidatedRuntime:$AllowUnvalidatedRuntime `
    -DisablePch:$DisablePch `
    -DisableFrameTrace:$DisableFrameTrace

$repoRoot = Get-Fo4HdrRepoRoot
Push-Location $repoRoot
try {
    xmake build -v
    if ($LASTEXITCODE -ne 0) {
        throw "Build failed."
    }

    foreach ($relative in @(
        "universal/Data/F4SE/Plugins/MakoFO4HDR/Default.ini",
        "universal/Data/F4SE/Plugins/MakoFO4HDR/runtime-1.10.163.json",
        "universal/Data/F4SE/Plugins/MakoFO4HDR/runtime-1.10.984.json",
        "universal/Data/F4SE/Plugins/MakoFO4HDR/runtime-1.11.240.json"
    )) {
        $retiredFile = Resolve-Fo4HdrChildPath `
            -Parent (Join-Path $repoRoot "dist") `
            -RelativePath $relative
        if (Test-Path -LiteralPath $retiredFile -PathType Leaf) {
            Remove-Item -LiteralPath $retiredFile -Force
        }
    }

    xmake install -v MakoFO4HDR
    if ($LASTEXITCODE -ne 0) {
        throw "Plugin staging failed."
    }
}
finally {
    Pop-Location
}

& (Join-Path $PSScriptRoot "verify-plugin-metadata.ps1") `
    -Mode $Mode
