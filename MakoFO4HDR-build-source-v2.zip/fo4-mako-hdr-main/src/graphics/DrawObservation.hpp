// SPDX-License-Identifier: LicenseRef-FO4Isotope-GPL-3.0-or-later-with-CommonLibF4-Exceptions

#pragma once

#include "d3d11/ContextQuerySafety.hpp"
#include "RenoDxShaderIdentity.hpp"
#include "FO4Isotope/output/RenderPipelineContract.hpp"
#include <d3d11.h>
#include <wrl/client.h>
#include <cstdint>

namespace fo4hdr {

struct DrawObservation
{
    bool immediate{};
    std::uint64_t generation{};
    ContextQuerySafety computeQueries{};
    ID3D11RenderTargetView* currentPrimaryRtv{};
    ID3D11RenderTargetView* currentSecondaryRtv{};
    bool currentSinglePresentationTarget{};
    RenoDxShaderPass currentPass{};
    bool currentPassKnown{};
    bool currentReplacementActive{};
    ID3D11PixelShader* expectedBoundShader{};
    // Retain the native binding only while substituted so production can disable between draws.
    Microsoft::WRL::ComPtr<ID3D11PixelShader> nativePixelShader;
    PipelinePassRequirement currentRequirement{PipelinePassRequirement::untracked};
};
using RenderTargetSetter = void(STDMETHODCALLTYPE*)(ID3D11DeviceContext*, UINT, ID3D11RenderTargetView* const*, ID3D11DepthStencilView*);
DrawObservation* FindDrawObservation(ID3D11DeviceContext*) noexcept;
RenderTargetSetter OriginalRenderTargetSetter(ID3D11DeviceContext*) noexcept;
bool HasOriginalPixelShaderSetter(ID3D11DeviceContext*) noexcept;
void BindOriginalPixelShader(ID3D11DeviceContext*, ID3D11PixelShader*) noexcept;

} // namespace fo4hdr
