// SPDX-License-Identifier: LicenseRef-FO4Isotope-GPL-3.0-or-later-with-CommonLibF4-Exceptions

#pragma once

#include "FO4Isotope/output/RenderPipelineContract.hpp"
#include <d3d11_1.h>
#include <dxgi1_4.h>
#include <wrl/client.h>
#include <array>
#include <cstdint>

namespace fo4hdr {

struct ArmorEncodedConstants
{
    std::uint32_t encode{};
    float peakUiRelative{1.0F};
    std::uint32_t sharedSrgb{};
    std::uint32_t reserved{};
};
static_assert(sizeof(ArmorEncodedConstants) == 16);


struct ArmorCompositionResources
{
    Microsoft::WRL::ComPtr<ID3D11ComputeShader> armorEncodedShader;
    std::array<Microsoft::WRL::ComPtr<ID3D11Buffer>, 2> armorEncodedConstants;
    float armorEncodedPeakUiRelative{};
    float armorEncodedWhite{};
    std::uintptr_t armorEncodedResource{};
    Microsoft::WRL::ComPtr<ID3D11DeviceContext1> armorEncodedContext1;
    bool armorEncodedAttempted{};
    bool armorEncodedActive{};
    bool armorEncodedFailed{};
    bool armorEncodedSharedSrgb{};
    std::uint64_t armorEncodedScope{}, armorEncodedGeneration{}, armorEncodedFrame{};
    std::uint64_t armorEncodedContextGeneration{};
    std::uint32_t armorEncodedThread{};
    const char* armorEncodedStatus{"Off"};
};
extern ArmorCompositionResources g_armor;

void EnsureArmorEncodedResources(ID3D11Device*, ID3D11DeviceContext*) noexcept;
void ResetArmorCompositionResources() noexcept;

} // namespace fo4hdr
