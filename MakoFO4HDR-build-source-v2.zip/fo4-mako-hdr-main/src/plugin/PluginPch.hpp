// SPDX-License-Identifier: LicenseRef-FO4Isotope-GPL-3.0-or-later-with-CommonLibF4-Exceptions
#pragma once

// Let CommonLib establish its Win32 declarations before any source-level
// Windows SDK headers are reached through the plugin's shared PCH.
#include <F4SE/F4SE.h>

#include <atomic>
#include <cstdint>
#include <memory>
#include <string>
#include <string_view>
